@extends('admin.layout.app')
@section('page-title', 'Application Details')

@section('section')
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row mb-3">
                            <div class="col-md-12 text-right">
                                <a href="{{ route('admin.user.application.list') }}" class="btn btn-sm btn-primary"> <i class="fa fa-chevron-left"></i> Back</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul>
                            <li><strong> Registration ID: </strong>{{$data->registration_id}}</li>
                            <li><strong> Job Title: </strong>{{$data->Jobs?$data->Jobs->title:""}}</li>
                            <li><strong> Name: </strong>{{$data->name}}</li>
                            <li><strong> Father's Name: </strong>{{$data->father_name}}</li>
                            <li><strong> Email: </strong>{{$data->email}}</li>
                            <li><strong> Mobile: </strong>{{$data->phone}}</li>
                            <li><strong> DOB: </strong>{{$data->date_of_birth}}</li>
                            <li><strong> Gender: </strong>{{$data->gender}}</li>
                            <li><strong> Marital Status: </strong>{{$data->merital_status}}</li>
                            <li><strong> Address: </strong>{{$data->address}}</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
@section('script')
@endsection