
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link <?php echo e((request()->is('admin/dashboard')) ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="nav-item <?php echo e((request()->is('admin/career*')) ? 'menu-open' : ''); ?>">
                <a href="#" class="nav-link <?php echo e((request()->is('admin/career*')) ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-file-alt"></i>
                    <p>Career Management <i class="right fas fa-angle-left"></i></p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.collection.list.all')); ?>" class="nav-link <?php echo e((request()->is('admin/career/collection*')) ? 'active active_nav_link' : ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Collections</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.job_category.list.all')); ?>" class="nav-link <?php echo e((request()->is('admin/career/job-category*')) ? 'active active_nav_link' : ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Job Categories</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.job.list')); ?>" class="nav-link <?php echo e((request()->is('admin/career/job-vacancy*')) ? 'active active_nav_link' : ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Job Vacancies</p>
                        </a>
                    </li>
                    
                </ul>
            </li>
            
            
            <li class="nav-item">
                <a class="nav-link" href="javascript:void(0)" onclick="event.preventDefault();document.getElementById('logout-form').submit()">
                    <i class="nav-icon fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </ul>
    </nav>
            <?php /**PATH C:\xampp\htdocs\Laravel\TechnoIndia\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>