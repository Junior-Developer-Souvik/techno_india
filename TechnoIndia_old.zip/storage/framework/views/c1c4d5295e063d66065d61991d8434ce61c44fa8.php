<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($settings[4]->content); ?> - <?php echo $__env->yieldContent('page-title'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('backend-assets/images/logo.jpg')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?php echo e(asset('backend-assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend-assets/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend-assets/css/style.css')); ?>">

    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link" target="_blank">Website</a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">Dashboard</a>
                </li>
            </ul>

            <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fas fa-th-large"></i>
                </a>
            </li>
            </ul>
        </nav>

        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="<?php echo e(url('/')); ?>" class="brand-link text-center admin_web_logo" target="_blank">
                <img src="<?php echo e(asset('backend-assets/images/full_logo.png')); ?>" alt="AdminLTE Logo" class="elevation-3" style="height: 45px;opacity: .8">
                
            </a>

            <div class="sidebar">
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                    <img src="<?php echo e(asset('backend-assets/images/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
                </div>
                <div class="info">
                    <a href="#" class="d-block">Admin</a>
                </div>
            </div>

            <div class="form-inline">
                <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                    <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
                </div>
            </div>
            <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </aside>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo $__env->yieldContent('page-title'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><?php echo $__env->yieldContent('page-title'); ?></li>
                        </ol>
                    </div>
                    </div>
                </div>
            </div>

            <?php echo $__env->yieldContent('section'); ?>

        </div>

        <aside class="control-sidebar control-sidebar-dark">
            <div class="p-3">
                <h5>Title</h5>
                <p>Sidebar content</p>
            </div>
        </aside>

        <footer class="main-footer">
            <div class="float-right d-none d-sm-inline">
                &copy; <?php echo e($settings[3]->content); ?> All rights reserved
            </div>
            <strong><?php echo e(date('Y')); ?> - <a href="<?php echo e(url('/')); ?>" target="_blank"><?php echo e($settings[3]->content); ?></a></strong>
        </footer>
    </div>
    <form action="<?php echo e(route('admin.logout')); ?>" id="logout-form" method="post" class="d-none"><?php echo csrf_field(); ?></form>

    <script src="<?php echo e(asset('backend-assets/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend-assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend-assets/js/adminlte.min.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('backend-assets/js/custom.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.0.0/classic/ckeditor.js"></script>

    <script>
        <?php if(Session::get('success')): ?>
            toastFire('success', '<?php echo e(Session::get("success")); ?>');
        <?php endif; ?>

        <?php if(Session::get('failure')): ?>
            toastFire('error', '<?php echo e(Session::get("failure")); ?>');
        <?php endif; ?>
    </script>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\TechnoIndia\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>