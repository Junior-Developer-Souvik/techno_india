
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('section'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            
            
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TechnoIndia\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>